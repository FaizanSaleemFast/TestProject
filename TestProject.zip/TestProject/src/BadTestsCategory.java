
public interface BadTestsCategory {

}
